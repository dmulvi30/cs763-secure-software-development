let footer = document.querySelector("footer");

let footer_body = `
<a class = "footer-links" href="https://www.filmsite.org/">FilmSite</a>
<a class = "footer-links" href="https://www.imdb.com">IMDb</a>
<a class = "footer-links" href="https://www.metacritic.com">MetaCritic</a> 
<a class = "footer-links" href="https://www.rogerebert.com/reviews">RogerEbert.com</a>
<a class = "footer-links" href="https://www.rottentomatoes.com">Rotten Tomatoes</a>        
    `;

footer.innerHTML = footer_body