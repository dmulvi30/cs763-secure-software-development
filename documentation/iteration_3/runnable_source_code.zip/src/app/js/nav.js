let nav = document.querySelector("nav");
let nav_body = `
<a class = "footer-links" href="https://www.filmsite.org/" class="href">Filmite</a>
<a class = "footer-links" href="https://www.imdb.com" class="href>IMDb</a>
<a class = "footer-links" href="https://www.metacritic.com" class="href>MetaCritic</a> 
<a class = "footer-links" href="https://www.rogerebert.com/reviews" class="href>RogerEbert.com</a>
<a class = "footer-links" href="https://www.rottentomatoes.com" class="href>Rotten Tomatoes</a>        
    `;

nav.innerHTML = nav_body;