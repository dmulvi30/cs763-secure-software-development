let header = document.querySelector("header");

let header_body = `<img src="../assets/logo.png">`;

header.innerHTML = header_body;