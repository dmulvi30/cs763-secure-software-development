let head = document.querySelector("head");

let head_body = `
    <meta charset="UTF-8">
    <meta name="description" content="Free Web tutorials">
    <meta name="keywords" content="HTML, CSS, JavaScript">
    <meta name="author" content="John Doe">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="static/css/styles.css" />
    <link rel="stylesheet" href="static/css/styles.css" />
    <title>BUMTV</title>   
    `;

head.innerHTML = head_body