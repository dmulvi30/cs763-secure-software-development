USE flask_app_db;

SELECT * FROM users;